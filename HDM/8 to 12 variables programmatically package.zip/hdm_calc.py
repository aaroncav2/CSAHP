#!/usr/bin/env python3
"""
HDM calculator: same math as the HDM_n_Variables.xlsx workbooks, for any number of variables.

Usage
    python hdm_calc.py HDM_8_Variables.xlsx          # reads the 'Input and Orientations' tab
    python hdm_calc.py HDM_9_Variables_compact.xlsx --update   # also writes the results into that workbook
    python hdm_calc.py inputs.csv                    # lower-triangle CSV (see below)
    python hdm_calc.py inputs.csv --rsv HDM_8_Variables.xlsx   # also bracket the RSV table percentile
    python hdm_calc.py inputs.csv --out results.csv  # results CSV name (default: <input name>_results.csv)

Output: results are always printed and saved to a CSV next to the input file. With --update, the average
scores, std devs and the inputs snapshot are written into the Rankings tab of the compact workbook
(layout produced with HDM_n_Variables_compact.xlsx); open it in Excel afterwards to recalculate.

CSV format: one row per variable i2, i3, ..., each holding its comparisons against i1..i(i-1):
    82
    28,23
    32,31,28
(this is the same lower triangle you type into the User Input block).

Every entry must be strictly between 0 and 100. Requires numpy; openpyxl only for .xlsx input.
Memory stays small because permutations are processed in chunks (9 variables: about a second,
10 variables: a few seconds).
"""
import argparse, csv, itertools, math, sys
import numpy as np

SHEET_INPUT = 'Input and Orientations'
SHEET_RSV = 'RSV lookup table by #Variables'


def read_inputs_xlsx(path):
    import openpyxl
    ws = openpyxl.load_workbook(path, data_only=True)[SHEET_INPUT]
    n = 0
    while isinstance(ws.cell(2, n + 1).value, str) and ws.cell(2, n + 1).value.startswith('i') \
            and ws.cell(2, n + 1).value[1:].isdigit():
        n += 1
    if n < 3:
        sys.exit('Could not find the User Input header (i1, i2, ...) in cells A2 onward.')
    return n, {(i, j): ws.cell(2 + i, j).value for i in range(2, n + 1) for j in range(1, i)}


def read_inputs_csv(path):
    rows = [[float(x) for x in r if x.strip() != ''] for r in csv.reader(open(path)) if any(x.strip() for x in r)]
    n = len(rows) + 1
    inputs = {}
    for i, r in enumerate(rows, start=2):
        if len(r) != i - 1:
            sys.exit(f'Row for i{i} needs {i - 1} values, found {len(r)}.')
        for j, v in enumerate(r, start=1):
            inputs[(i, j)] = v
    return n, inputs


def pair_matrix(n, inputs):
    """P[k, j] = average over rows i of R[i,k] / R[i,j]  (the 'Reference' averages / Vlookup tab)."""
    raw = np.zeros((n, n))
    for (i, j), v in inputs.items():
        if v is None or not (0 < float(v) < 100):
            sys.exit(f'Input for (i{i}, i{j}) must be strictly between 0 and 100 (got {v!r}).')
        raw[i - 1, j - 1] = v
        raw[j - 1, i - 1] = 100 - v
    R = np.ones((n, n))
    for i in range(n):
        for j in range(n):
            if i != j:
                R[i, j] = raw[i, j] / raw[j, i]
    return np.array([[np.mean(R[:, k] / R[:, j]) for j in range(n)] for k in range(n)])


def compute(n, inputs, chunk=200_000):
    P = pair_matrix(n, inputs)
    count, mean, m2 = 0, np.zeros(n), np.zeros(n)
    perms = itertools.permutations(range(n))
    while True:
        block = list(itertools.islice(perms, chunk))
        if not block:
            break
        perm = np.array(block, dtype=np.int8)
        o = P[perm[:, :-1], perm[:, 1:]]                                  # adjacent-pair averages
        w = np.concatenate([np.cumprod(o[:, ::-1], axis=1)[:, ::-1],       # raw weights by position
                            np.ones((len(perm), 1))], axis=1)
        w /= w.sum(axis=1, keepdims=True)                                  # normalize
        full = np.empty_like(w)
        np.put_along_axis(full, perm.astype(np.int64), w, axis=1)          # back to item order A, B, C...
        m = len(full)
        bm, bm2 = full.mean(axis=0), ((full - full.mean(axis=0)) ** 2).sum(axis=0)
        delta = bm - mean                                                  # Chan et al. parallel update
        tot = count + m
        mean = mean + delta * m / tot
        m2 = m2 + bm2 + delta ** 2 * count * m / tot
        count = tot
    sd = np.sqrt(m2 / (count - 1))                                         # sample std dev (Excel STDEV)
    return {'n': n, 'perms': count, 'avg': mean, 'sd': sd, 'hdm': float(sd.mean()),
            'sqrt_sumsq': float(math.sqrt((sd ** 2).sum()))}


def rsv_bracket(xlsx_path, n, value):
    """Percentiles in the RSV table (column for n variables) just below / above value."""
    import openpyxl
    ws = openpyxl.load_workbook(xlsx_path, data_only=True)[SHEET_RSV]
    col = next((c for c in range(2, 14) if str(ws.cell(1, c).value) == str(n)), None)
    if col is None:
        return None
    table = [(ws.cell(r, 1).value, ws.cell(r, col).value) for r in range(2, 52)]
    lower = [p for p, v in table if v <= value]
    upper = [p for p, v in table if v > value]
    return (max(lower) if lower else None, min(upper) if upper else None)


def update_compact(path, n, inputs, res):
    """Write avg / std dev / inputs snapshot into the Rankings tab of a compact workbook (in place)."""
    import openpyxl
    wb = openpyxl.load_workbook(path)
    ws = wb['Rankings']
    label_col = n + 3
    rows = {ws.cell(r, label_col).value: r for r in range(1, ws.max_row + 1)
            if isinstance(ws.cell(r, label_col).value, str)}
    snap = next((r for r in range(1, ws.max_row + 1)
                 if str(ws.cell(r, 2).value or '').startswith('Inputs used for the results above')), None)
    if 'average score' not in rows or 'std dev' not in rows or snap is None:
        sys.exit('--update needs the compact workbook layout (Rankings tab with results and inputs-snapshot blocks).')
    for m in range(n):
        ws.cell(rows['average score'], 3 + m).value = float(res['avg'][m])
        ws.cell(rows['std dev'], 3 + m).value = float(res['sd'][m])
    for (i, j), v in inputs.items():
        ws.cell(snap + 1 + i, 2 + j).value = v          # header row is snap+1, item i is snap+1+i
    wb.calculation.fullCalcOnLoad = True
    wb.save(path)
    print('updated', path, '(open in Excel to recalculate)')


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('input'); ap.add_argument('--out'); ap.add_argument('--rsv')
    ap.add_argument('--update', action='store_true', help='write results into the compact workbook given as input')
    a = ap.parse_args()
    n, inputs = read_inputs_xlsx(a.input) if a.input.lower().endswith(('.xlsx', '.xlsm')) else read_inputs_csv(a.input)
    res = compute(n, inputs)
    names = [chr(ord('A') + k) for k in range(n)]
    print(f"{n} variables, {res['perms']:,} permutations")
    print('item    average score    std dev')
    for k in range(n):
        print(f"  {names[k]}        {res['avg'][k]:.5f}       {res['sd'][k]:.5f}")
    print(f"HDM Inconsistency (mean std dev):            {res['hdm']:.5f}")
    print(f"Square root of summed variances (RSV lookup): {res['sqrt_sumsq']:.5f}")
    src = a.rsv or (a.input if a.input.lower().endswith('.xlsx') else None)
    if src:
        br = rsv_bracket(src, n, res['sqrt_sumsq'])
        if br:
            lo, hi = br
            if lo is None:
                msg = f'below the lowest tabulated percentile ({hi})'
            elif hi is None:
                msg = f'at or above the highest tabulated percentile ({lo})'
            else:
                msg = f'between table percentiles {lo} and {hi}'
            print(f'RSV table ({n} variables): value falls {msg}')
    import os
    out = a.out or os.path.splitext(a.input)[0] + '_results.csv'
    with open(out, 'w', newline='') as f:
        w = csv.writer(f)
        w.writerow(['item', 'average_score', 'std_dev'])
        for k in range(n):
            w.writerow([names[k], res['avg'][k], res['sd'][k]])
        w.writerow(['HDM Inconsistency', res['hdm'], ''])
        w.writerow(['sqrt_sum_sq_std_dev', res['sqrt_sumsq'], ''])
    print('wrote', out)
    if a.update:
        if not a.input.lower().endswith('.xlsx'):
            sys.exit('--update only works when the input is the compact .xlsx workbook.')
        update_compact(a.input, n, inputs, res)
    elif a.input.lower().endswith('.xlsx') and 'compact' in os.path.basename(a.input).lower():
        print('Tip: add --update to write these results into the workbook.')


if __name__ == '__main__':
    main()
